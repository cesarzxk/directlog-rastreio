# directlog-rastreio
Rastreio para Direct Logistica.

Extraia o arquivo '. Extract-me.zip' no diretório.
